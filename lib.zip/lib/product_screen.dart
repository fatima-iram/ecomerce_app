import 'package:flutter/material.dart';
import 'package:flutter_application_1/cart.dart';
import 'classes.dart';

class ProductScreen extends StatefulWidget {
  const ProductScreen({super.key});

  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

// bool BUY = false;

class _ProductScreenState extends State<ProductScreen> {
  bool isBought = false;
  void clickFunction() {
    setState(() {
      isBought = !isBought;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: const Color.fromARGB(255, 72, 149, 203),
      appBar: AppBar(
        title: const Text("wireless keyboard"),
      ),
      body: Center(
        child: SizedBox(
          height: 1000,
          width: 500,
          child: Column(
            children: [
              SizedBox(
                height: 200,
                width: 150,
                child: Image.network(
                  "https://m.media-amazon.com/images/I/31ra3vyVcrL._SX300_SY300_QL70_FMwebp_.jpg",
                  // fit: BoxFit.cover,
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        'Wireless keyboard',
                        style: TextStyle(fontSize: 30),
                      ),
                      Text(
                        '₹982.5',
                        style: TextStyle(fontSize: 20),
                      ),
                    ],
                  ),
                  const Text(
                    'A smooth and responsive wireless keyboard',
                    style: TextStyle(color: Colors.black54),
                  ),
//                   Use the conditional expression/Ternary operator for the " Buy " and " Bought " text inside the button.
                  // If you don't know what it is, it works like if-else but in a single format

                  // syntax is: condition ? exprIfTrue : exprIfFalse

                  // for example
                  // isBought ? "Bought" : "Buy"

                  // Here if isBought boolean value is true " Bought " will be selected (after question mark), else " Buy " will be selected

                  ElevatedButton(
                    onPressed: clickFunction,
                    child: Text(isBought ? "Bought" : "BUY"),
                    // bool isBought = true;
                    // bool BUY = false;
                    // isBought ? "Bought" : "BUY";
                    // print("Nice Choice!");

                    //  child: Text("BUY"),
                  ),
                  IconButton(
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) => cart()));
                    },
                    icon: Icon(Icons.shopping_basket),
                  )
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
