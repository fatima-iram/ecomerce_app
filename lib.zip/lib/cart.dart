import 'package:flutter/material.dart';

class cart extends StatelessWidget {
  const cart({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(45 - 98),
      appBar: AppBar(
        title: const Text("CART"),
      ),
      body: const Center(),
    );
  }
}
